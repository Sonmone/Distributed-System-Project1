package activitystreamer;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import activitystreamer.client.ClientSkeleton;
import activitystreamer.util.Settings;


/*
 *ClassName: Client
 *Version: 3.0
 *Authors: Zhao, Song, Fan and Zhang
 */
public class Client {
	//state the initializion of Log function
	private static final Logger log = LogManager.getLogger();

	/*
   *FunctionName: help
	 *Parameter: options
	 *Return: Null
	 *Description: Print help strings when clients run this class
	 */
	private static void help(Options options){
		String header = "An ActivityStream Client for Unimelb COMP90015\n\n";
		String footer = "\ncontact aharwood@unimelb.edu.au for issues.";
		HelpFormatter formatter = new HelpFormatter();
		formatter.printHelp("ActivityStreamer.Client", header, options, footer, true);
		System.exit(-1);
	}

	/*
   *FunctionName: main
	 *Parameter: args
	 *Return: Null
	 *Description: scan options in CMD args, and set initial parameters in Settings
	 *Cmd: activitystreamer.Client -u (username) -rh (remoteHost) -rp (remotePort) -s (secret)
	 */
	public static void main(String[] args) {

		log.info("reading command line options");

		Options options = new Options();
		options.addOption("u",true,"username"); //-u username
		options.addOption("rp",true,"remote port number"); //-rp remotePort
		options.addOption("rh",true,"remote hostname"); //-rh remoteHost
		options.addOption("s",true,"secret for username"); //-s secret


		// build the parser
		CommandLineParser parser = new DefaultParser();

		CommandLine cmd = null;
		try {
			cmd = parser.parse( options, args);
		} catch (ParseException e1) {
			help(options);
		}

		//set remote host name in Settings
		if(cmd.hasOption("rh")){
			Settings.setRemoteHostname(cmd.getOptionValue("rh"));
		}

		//set remote port name in Settings
		if(cmd.hasOption("rp")){
			try{
				int port = Integer.parseInt(cmd.getOptionValue("rp"));
				Settings.setRemotePort(port);
			} catch (NumberFormatException e){
				log.error("-rp requires a port number, parsed: "+cmd.getOptionValue("rp"));
				help(options);
			}
		}

		//set secret in Settings
		if(cmd.hasOption("s")){
			Settings.setSecret(cmd.getOptionValue("s"));
		}

		//set username in Settings
		if(cmd.hasOption("u")){
			Settings.setUsername(cmd.getOptionValue("u"));
		}


		log.info("starting client");

		//instantiate ClientSkeleton for clients
		ClientSkeleton c = ClientSkeleton.getInstance();
	}


}
