package activitystreamer.server;

import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import activitystreamer.util.*;

/*
 *ClassName: Control
 *Version: 3.0
 *Authors: Zhao, Song, Fan and Zhang
 */
public class Control extends Thread {
	//state the initializion of Log function
	private static final Logger log = LogManager.getLogger();
	//storage all connections linked to this server
	private static ArrayList<Connection> connections;
	//use term to control a status of connection
	private static boolean term=false;
	//state the initializion of a listen function
	private static Listener listener;
	//use gson to format strings to JSON
	private static Gson gson = new Gson();
	//storage all authenticated clients linked to this server
	private static ArrayList<Connection> clients;
	//storage the users login successfully
	private static HashMap<String, String> login;
	//storage all authenticated servers linked to this server
	private static ArrayList<Connection> servers;
	//used to declare server announcement, with serverID and announcement infomation
	private static HashMap<String, ServerState> announceTable;
	//storage a tempory register user map, with username and the connection
	private static HashMap<String, UserDetail> registerWaiting;
	//represent this server's ID
	private static String id;
	//represent this server's load
	private static int ownLoad;
	//used to parser JSON type
	private static JSONParser parser;
	//state the initializion of a control function
	protected static Control control = null;

	/*
   *FunctionName: getInstance
	 *Parameter: null
	 *Return: Control
	 *Description: instantiate a Control class
	 */
	public static Control getInstance() {
		if(control==null){
			control=new Control();
		}
		return control;
	}

	/*
	 *ClassName: Control
	 *Version: 3.0
	 *Authors: Zhao, Song, Fan and Zhang
	 */
	public Control() {
		parser = new JSONParser(); //used to parser Json Object
		// initialize the connections array
		connections = new ArrayList<Connection>();
		//all connections from clients connecting to this server
		clients = new ArrayList<Connection>();
		//all connections from servers connecting to this server
		servers = new ArrayList<Connection>();
		//the clients who have login successfully, with username and secret
		login = new HashMap<String, String>();
		//used to declare server announcement, with serverID and announcement infomation
		announceTable = new HashMap<String, ServerState>();
		//storage a tempory register user map, with username and the connection
		registerWaiting = new HashMap<String, UserDetail>();
		// start a listener
		log.info("Initialising Connection");
		//judge the register condition and login
		initiateConnection();
		try {
			listener = new Listener(); //listen for incoming connection
		} catch (IOException e1) {
			log.fatal("failed to startup a listening thread: "+e1);
			System.exit(-1);
		}
		//get the unique ID for this server
		id = Settings.nextSecret();
	}

	/*
   *FunctionName: run
	 *Parameter: null
	 *Return: Null
	 *Description: run the server and set a regular sleeping interval
	 */
	@Override
	public void run(){
		log.info("using activity interval of "+Settings.getActivityInterval()+" milliseconds");
		//term initialized as false, means that the connection maintains
		while(!term){
			// do something with 5 second intervals in between
			try {
				Thread.sleep(Settings.getActivityInterval());
			} catch (InterruptedException e) {
				log.info("received an interrupt, system is shutting down");
				break;
			}
			if(!term){
				log.debug("doing activity");
				term=doActivity();
			}

		}
		//if the connection shut down, close these connections
		log.info("closing "+connections.size()+" connections");
		// clean up
		for(Connection connection : connections){
			connection.closeCon();
		}
		listener.setTerm(true);
		System.exit(-1);
	}

	/*
   *FunctionName: initiateConnection
	 *Parameter: null
	 *Return: Null
	 *Description: judge whether the user can successfully register and login
	 */
	public void initiateConnection(){
		// make a connection to another server if remote hostname is supplied
		if(Settings.getRemoteHostname()!=null){
			try {
				//create the socket of TCP to connect the target server
				Connection serverCon = outgoingConnection(new Socket(Settings.getRemoteHostname(),Settings.getRemotePort()));
				//create ServerMessage instance with AUTHENTICATE instruction
				ServerMessage authenticate = new ServerMessage("AUTHENTICATE", Settings.getSecret());
				//send this JSON message
				serverCon.writeMsg(getJsonString(authenticate));
				//add this connection into connections list
				connections.add(serverCon);
				//add this connection into servers list
				servers.add(serverCon);
			} catch (IOException e) {
				log.error("failed to make connection to "+Settings.getRemoteHostname()+":"+Settings.getRemotePort()+" :"+e);
				System.exit(-1);
			}
		}
	}

	/*
   *FunctionName: connectionClosed
	 *Parameter: con
	 *Return: Null
	 *Description: remove one connection when it is closed
	 */
	public synchronized void connectionClosed(Connection con){
		//remove this connection
		if(!term) connections.remove(con);
	}

	 /*
    *FunctionName: incomingConnection
 	  *Parameter: socket
 	  *Return: Connection
 	  *Description: A new incoming connection has been established, and a reference is returned to it
 	  */
	public synchronized Connection incomingConnection(Socket s) throws IOException{
		log.debug("incomming connection: "+Settings.socketAddress(s));
		//instantiate a new socket
		Connection c = new Connection(s);
		//add this connection into connections list
		connections.add(c);
		return c;
	}

	 /*
    *FunctionName: outgoingConnection
 	  *Parameter: socket
 	  *Return: Connection
	  *Description: A new outgoing connection has been established, and a reference is returned to it
 	  */
	public synchronized Connection outgoingConnection(Socket s) throws IOException{
		log.debug("outgoing connection: "+Settings.socketAddress(s));
		//instantiate a new socket
		Connection c = new Connection(s);
		//add this connection into connections list
		connections.add(c);
		return c;
	}

	/*
	 *FunctionName: doActivity
	 *Parameter: null
	 *Return: true or false
	 *Description: announce this server's information to all other servers
	 */
	public boolean doActivity(){
		//get the number of connected clients
		ownLoad = clients.size();
		//the announcement includes id, hostname, load and port
		ServerAnnounce announceObj = new ServerAnnounce(id, ownLoad, Settings.getLocalHostname(), Settings.getLocalPort());
		//broadcast this Json type announcement to other servers
		multicast(null, getJsonString(announceObj));
		return false;
	}

	/*
	 *FunctionName: setTerm
	 *Parameter: true or false
	 *Return: null
	 *Description: announce set term with true or false which controls the connection status
	 */
	public final void setTerm(boolean t){
		term=t;
	}

	/*
	 *FunctionName: getConnections
	 *Parameter: null
	 *Return: a list of connections
	 *Description: get the list of all connection of this server
	 */
	public final ArrayList<Connection> getConnections() {
		return connections;
	}

	/*
	 *FunctionName: register
	 *Parameter: connection, username, secret
	 *Return: true or false
	 *Description: cope with the REGISTER instruction from a client
	 */
	public synchronized boolean register(Connection con, String username, String secret){
		//record the client's username and secret
		login.put(username, secret);
		//if the server does not connect to any other servers
		if(servers.isEmpty()){
			return true; //register successfully
		}
		else{
			//put this user into the waiting queue
			UserDetail waiting = new UserDetail(con);
			registerWaiting.put(username, waiting);
			//broadcast LOCK_REQUEST to all other servers
			ServerMessage lockRequest = new ServerMessage("LOCK_REQUEST", username, secret);
			multicast(null, getJsonString(lockRequest));
			return false;
		}
	}

	/*
	 *FunctionName: updateAnnounce
	 *Parameter: announcement message
	 *Return: null
	 *Description: when receiving other servers' announce, update the announceTable
	 */
	public synchronized void updateAnnounce(ServerAnnounce announceMsg){
		//get the server'ID of this announce
		String serverId = announceMsg.getId();
		//get the server' load of this announce
		int load = announceMsg.getLoad();
		//judge whether that server has been known by this one
		if(announceTable.containsKey(serverId)){
			announceTable.get(serverId).setLoad(load);
		}
		else{
			//insert that server's information into announceTable
			String serverHost = announceMsg.getHostname();
			int serverPort = announceMsg.getPort();
			ServerState newState = new ServerState(serverId, serverHost, serverPort, load);
			announceTable.put(serverId, newState);
		}
	}

	/*
	 *FunctionName: checkRedirect
	 *Parameter: connection
	 *Return: true or false
	 *Description: judge wheter need to redirect the client's login to another server
	 */
	public boolean checkRedirect(Connection con){
		boolean needRedirect = false;
		String redirectHost = null;
		int redirectPort = 0;
		//if the load of this server exceed more than 2 of other servers, redirect this connection request
		for(ServerState other: announceTable.values()){
			if((ownLoad - other.getLoad()) >= 2){
				redirectHost = other.getHostname();
				redirectPort = other.getPort();
				needRedirect = true;
				break;
			}
		}
		if(needRedirect){
			//create redirection message
			RedirectMessage redictObj = new RedirectMessage(redirectHost, redirectPort);
			con.writeMsg(getJsonString(redictObj));
			//remove this connection from connections list
			removeClient(con);
		}
		return needRedirect;
	}

	/*
	 *FunctionName: getLoginTable
	 *Parameter: null
	 *Description: Return: a hashmap with login information
	 */
	public static HashMap<String, String> getLoginTable(){
		return login;
	}

	/*
	 *FunctionName: getLockTable
	 *Parameter: null
	 *Return: a hashmap with register waitting information
	 */
	public static HashMap<String, UserDetail> getLockTable(){
		return registerWaiting;
	}

	/*
	 *FunctionName: multicast
	 *Parameter: connection and message needed to multicast
	 *Return: null
	 *Description: multicast determined messages to all other servers
	 */
	public synchronized void multicast(Connection con, String msg){
		for(Connection connection : servers){
			//except the connection giving this message
			if(con !=null && connection.equals(con)){
				continue;
			}
			connection.writeMsg(msg);
		}
	}

	/*
	 *FunctionName: msgBroadcast
	 *Parameter: message needed to broadcast
	 *Return: null
	 *Description: broadcast determined messages to all other servers
	 */
	public synchronized void msgBroadcast(String msg){
		for(Connection connection: clients){
			connection.writeMsg(msg);
		}
	}

	/*
	 *FunctionName: isClient
	 *Parameter: connection
	 *Return: true or false
	 *Description: judge whether a connection is a client
	 */
	public boolean isClient(Connection con){
		if(clients.contains(con)){
			return true;
		}
		else{
			return false;
		}
	}

	/*
	 *FunctionName: isServer
	 *Parameter: connection
	 *Return: true or false
	 *Description: judge whether a connection is a server
	 */
	public boolean isServer(Connection con){
		if(servers.contains(con)){
			return true;
		}
		else{
			return false;
		}
	}

	/*
	 *FunctionName: removeCon
	 *Parameter: connection
	 *Return: null
	 *Description: remove a connection from its related list
	 */
	public synchronized void removeCon(Connection con){
		if(!term){
			if(isClient(con)){
				removeClient(con);
			}
			else if(isServer(con)){
				removeServer(con);
			}
			else{
				connectionClosed(con);
			}
		}
	}

	/*
	 *FunctionName: getJsonString
	 *Parameter: a object of message
	 *Return: JSON string
	 *Description: use gson to format a string object to JSON type
	 */
	private <T> String getJsonString(T msfObj){
		String msg = gson.toJson(msfObj);
		return msg;
	}

	/*
	 *FunctionName: addClient
	 *Parameter: connection
	 *Return: null
	 *Description: add a client connection into related list
	 */
	public synchronized void addClient(Connection con){
		if(!term) clients.add(con);
	}

	/*
	 *FunctionName: addServer
	 *Parameter: connection
	 *Return: null
	 *Description: add a server connection into related list
	 */
	public synchronized void addServer(Connection con){
		if(!term) servers.add(con);
	}

	/*
	 *FunctionName: removeClient
	 *Parameter: connection
	 *Return: null
	 *Description: remove a client connection into related list and close the connection
	 */
	public synchronized void removeClient(Connection con){
		if(!term) {
			clients.remove(con);
			connectionClosed(con);
		}
	}

	/*
	 *FunctionName: removeServer
	 *Parameter: connection
	 *Return: null
	 *Description: remove a server connection into related list and close the connection
	 */
	public synchronized void removeServer(Connection con){
		if(!term) {
			servers.remove(con);
			connectionClosed(con);
		}
	}

	public static synchronized void addUser(String username, String secret){
		login.put(username, secret);
	}

	/*
	 *FunctionName: deleteUser
	 *Parameter: username
	 *Return: null
	 *Description: delete a user infomation from login list
	 */
	public static synchronized void deleteUser(String username){
		login.remove(username);
	}

	/*
	 *FunctionName: announceTableSize
	 *Parameter: null
	 *Return: an interger of the announceTable's size
	 */
	public static int announceTableSize(){
		return announceTable.size();
	}
}
