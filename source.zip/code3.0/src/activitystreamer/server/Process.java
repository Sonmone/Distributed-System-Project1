package activitystreamer.server;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.google.gson.Gson;
import com.google.gson.JsonParseException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import activitystreamer.util.*;

/*
 *ClassName: Process
 *Version: 3.0
 *Authors: Zhao, Song, Fan and Zhang
 */
public class Process extends Thread{
	//state the initializion of Log function
	private static final Logger log = LogManager.getLogger();
	//state the initializion of a connection
	private Connection con;
	//use term to control a status of connection
	private boolean term = false;
	//used to parser JSON type
	private static JSONParser parser;
	//use gson to format strings to JSON
	private static Gson gson;

	/*
   *FunctionName: Process
	 *Parameter: null
	 *Return: Null
	 *Description: Constructed Function
	 */
	public Process(Connection con){
		this.con = con;
		parser = new JSONParser();
		gson = new Gson();
		start();
	}

	/*
   *FunctionName: run
	 *Parameter: null
	 *Return: Null
	 *Description: run the server and set a regular sleeping interval
	 */
	@Override
	public void run(){
		while(!term){
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				break;
			}
		}
	}

	/*
   *FunctionName: msgProcess
	 *Parameter: message
	 *Return: true or false
	 *Description: process the response message
	 */
	public boolean msgProcess(String msg){
		boolean tempTerm = false;
		//connection is open
		if(!term){
			try{
				//get the command
				String command = parseCommand(msg);
				//if the connection is form a server
				if(Control.getInstance().isServer(con)){
					//process the server message
					tempTerm = processServer(command, msg);
				}
				//process the client message
				else if(Control.getInstance().isClient(con)){
					tempTerm = processClient(command, msg);
				}
				/*
				 *the first message to determine whether the connection
				 *is from a client or a server
				 */
				else {
					tempTerm = firstMessageProcess(command, msg);
				}
				return tempTerm;
			} catch(ParseException e){
				responseInfo("INVALID_MESSAGE", "Meaningless message");
				Control.getInstance().removeCon(con);
				return true;
			}
		}
		return tempTerm;
	}

	/*
   *FunctionName: processServer
	 *Parameter: command and message
	 *Return: true or false
	 *Description: process the message form a server
	 */
	private boolean processServer(String command, String msg) throws JsonParseException, ParseException{
		boolean tempTerm = false;
		//the command is SERVER_ANNOUNCE
		if(command.equals("SERVER_ANNOUNCE")){
			ServerAnnounce announceMsg = gson.fromJson(msg, ServerAnnounce.class);
			//update the announce table
			Control.getInstance().updateAnnounce(announceMsg);
		}
		else{
			//get username and secret
			ServerMessage serverMsg;
			serverMsg = gson.fromJson(msg, ServerMessage.class);
			String username = serverMsg.getUsername();
			String secret = serverMsg.getSecret();
			switch(command){
				//the command is LOCK_REQUEST
				case "LOCK_REQUEST":
					ServerMessage lockResponse;
					//judge if the user has registered here
					if(!Control.getLoginTable().containsKey(username)){
						//add the user infomation and send LOCK_ALLOWED
						Control.addUser(username, secret);
						lockResponse = new ServerMessage("LOCK_ALLOWED", username, secret);
					}
					else{
						//deny the register
						lockResponse = new ServerMessage("LOCK_DENIED", username, secret);
					}
					Control.getInstance().multicast(null, getJsonString(lockResponse));
					break;
				//the command is LOCK_DENIED
				case "LOCK_DENIED":
					//if the user has been record, delete it
					if(checkLogin(username, secret)){
						Control.deleteUser(username);
					}
					break;
				//the command is LOCK_ALLOWED
				case "LOCK_ALLOWED":
					//check if the user has been allowed by all servers
					checkLock(username, secret);
					break;
				//the command is ACTIVITY_BROADCAST
				case "ACTIVITY_BROADCAST":
					//broadcast this message
					Control.getInstance().msgBroadcast(msg);
					break;
				//the command is AUTHENTICATION_FAIL
				case "AUTHENTICATION_FAIL":
					log.error("wrong secret for the server");
				//the command is INVALID_MESSAGE
				case "INVALID_MESSAGE":
					tempTerm = true;
					//close connection
					Control.getInstance().setTerm(true);
					break;
				default:
					responseInfo("INVALID_MESSAGE", "Wrong command");
					tempTerm = true;
			}
		}
		if(!tempTerm){
			//multicast the message
			Control.getInstance().multicast(con, msg);
		}
		else{
			//remove the connection
			Control.getInstance().removeServer(con);
		}
		return tempTerm;
	}

	/*
   *FunctionName: processClient
	 *Parameter: command and message
	 *Return: true or false
	 *Description: process the message form a client
	 */
	private boolean processClient(String command, String msg) throws JsonParseException, ParseException{
		//get the username and secret of the client
		boolean tempTerm = false;
		ClientMessage clientMsg = gson.fromJson(msg, ClientMessage.class);
		String username = clientMsg.getUsername();
		String secret = clientMsg.getSecret();
		switch(command){
			//the command is LOGOUT
			case "LOGOUT":
				tempTerm = true;
				break;
			//the command is ACTIVITY_MESSAGE
			case "ACTIVITY_MESSAGE":
				//get the activity
				JSONObject clientActi = clientMsg.getActi();
				ServerMessage actiBroadObj = new ServerMessage("ACTIVITY_BROADCAST", clientActi);
				String atciBroadMsg = getJsonString(actiBroadObj);
				//broadcast this activity
				Control.getInstance().msgBroadcast(atciBroadMsg);
				Control.getInstance().multicast(null, atciBroadMsg);
				break;
			//the command is LOGIN
			case "LOGIN":
				//process by username and secret
				tempTerm = processLogin(username, secret);
				break;
			default:
				responseInfo("INVALID_MESSAGE", "Wrong command");
				tempTerm = true;
		}
		if(tempTerm){
			Control.getInstance().removeClient(con);
		}
		return tempTerm;
	}

	/*
   *FunctionName: firstMessageProcess
	 *Parameter: command and message
	 *Return: true or false
	 *Description: process the first message from a connection and
	 *             judge it is from a client or a server
	 */
	private boolean firstMessageProcess(String command, String msg) throws JsonParseException, ParseException{
		boolean isClientCommand = false;
		boolean isServerCommand = false;
		boolean tempTerm = false;
		switch(command){
			//REGISTER and LOGIN comes from a client
			case "REGISTER":
			case "LOGIN":
				isClientCommand = true;
				break;
			//AUTHENTICATE comes from a server
			case "AUTHENTICATE":
				isServerCommand = true;
				break;
			default:
				responseInfo("INVALID_MESSAGE", "Wrong command");
				tempTerm = true;
		}
		//the connection comes from a client
		if(isClientCommand){
			//get the username and secret
			ClientMessage clientMsg = gson.fromJson(msg, ClientMessage.class);
			String username = clientMsg.getUsername();
			String secret = clientMsg.getSecret();
			//the command is REGISTER
			if(command.equals("REGISTER")){
				//no username
				if(username == null){
					responseInfo("INVALID_MESSAGE", "There is not a username in the message.");
					tempTerm = true;
				}
				//username is anonymous
				else if(username.equals("anonymous")){
					responseInfo("REGISTER_FAILED", "Cannot register for anonymous username.");
					tempTerm = true;
				}
				else {
					//check whether the user had successfully registered
					if(Control.getInstance().getLoginTable().containsKey(username)){
						String info = String.format("%s is already registered with the system", username);
						responseInfo("REGISTER_FAILED", info);
						tempTerm = true;
					}
					else {
						if(Control.getInstance().register(con, username, secret)){
							String info = String.format("register success for %s", username);
							responseInfo("REGISTER_SUCCESS", info);
							Control.getInstance().addClient(con);
						}
					}
				}
			}
			else{
				//login with this username and secret
				tempTerm = processLogin(username, secret);
				if(!tempTerm){
					//add this client into related connection list
					Control.getInstance().addClient(con);
				}
			}
		}
		//the connection comes from a server
		else if(isServerCommand){
			//get the secret and judge if its correct
			ServerMessage serverMsg = gson.fromJson(msg, ServerMessage.class);
			String serverSecret = serverMsg.getSecret();
			if (!serverSecret.equals(Settings.getSecret())){
				String info = String.format("the supplied secret is incorrect: %s", serverSecret);
				responseInfo("AUTHENTICATION_FAIL", info);
				tempTerm = true;
			}
		}
		//the incoming server is legal
		if(tempTerm){
			Control.getInstance().connectionClosed(con);
		}
		else if(isServerCommand){
			//add this server into its related connection list
			Control.getInstance().addServer(con);
		}
		return tempTerm;
	}

	/*
   *FunctionName: processLogin
	 *Parameter: username and secret
	 *Return: true or false
	 *Description: process the login request
	 */
	private boolean processLogin(String username, String secret){
		//check whether the user has registered successfully
		if(checkLogin(username, secret)){
			String info = String.format("logged in as user %s", username);
			responseInfo("LOGIN_SUCCESS", info);
			//check whether the client need to redirect
			if(Control.getInstance().checkRedirect(con)){
				return true;
			}
			return false;
		}
		else{
			String info = String.format("attempt to login with wrong secret: %s", secret);
			responseInfo("LOGIN_FAILED", info);
			return true;
		}
	}

	/*
   *FunctionName: checkLogin
	 *Parameter: username and secret
	 *Return: true or false
	 *Description: check whether the user has registered successfully
	 */
	private boolean checkLogin(String username, String secret){
		HashMap<String, String> login = Control.getLoginTable();
		//the username is anonymous
		if (username.equals("anonymous")){
			return true;
		}
		//whether the user's infomation legal
		else if(login.containsKey(username) && login.get(username).equals(secret)){
			return true;
		}
		return false;
	}

	/*
   *FunctionName: checkLock
	 *Parameter: username and secret
	 *Return: true or false
	 *Description: check whether the lock request successfully
	 */
	private void checkLock(String username, String secret){
		HashMap<String, UserDetail> registerWaiting = Control.getLockTable();
		//get the number of allowed response from all other servers
		if (registerWaiting.containsKey(username)){
			UserDetail waitng = registerWaiting.get(username);
			int countAllow = waitng.getAllowCount();
			countAllow ++;
			//at least all other servers this server has known allowing this request
			if(countAllow >= Control.getInstance().announceTableSize()){
				Connection clientCon = waitng.getConnection();
				Control.getInstance().addClient(clientCon);
				registerWaiting.remove(username);
				String info = String.format("register success for %s", username);
				clientCon.writeMsg(getJsonString(new ServerMessage("REGISTER_SUCCESS", info)));
			}
			else{
				waitng.setAllowCount(countAllow);
			}
		}
	}

	/*
	 *FunctionName: setTerm
	 *Parameter: true or false
	 *Return: null
	 *Description: announce set term with true or false which controls the connection status
	 */
	public final void setTerm(boolean t){
		term=t;
	}

	/*
	 *FunctionName: responseInfo
	 *Parameter: command and information
	 *Return: null
	 *Description: response JSON message
	 */
	private void responseInfo(String command, String info){
		ServerMessage responseObj = new ServerMessage(command, info);
		log.error(info);
		con.writeMsg(getJsonString(responseObj));
	}

	/*
	 *FunctionName: parseCommand
	 *Parameter: message
	 *Return: string
	 *Description: get the command
	 */
	private String parseCommand(String msg) throws ParseException{
		JSONObject msgObj = (JSONObject) parser.parse(msg);
		String command = (String) msgObj.get("command");
		return command;
	}

	/*
	 *FunctionName: getJsonString
	 *Parameter: message
	 *Return: JSON String
	 *Description: get the JSON type string
	 */
	private <T> String getJsonString(T msfObj){
		String msg = gson.toJson(msfObj);
		return msg;
	}
}
