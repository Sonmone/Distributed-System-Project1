package activitystreamer.util;

/*
 *ClassName: ServerAnnounce
 *Version: 3.0
 *Authors: Zhao, Song, Fan and Zhang
 */
public class ServerAnnounce{
	//the command is SERVER_ANNOUNCE
	private String command = "SERVER_ANNOUNCE";
	private String id;
	private String hostname;
	private int port;
	private int load;

	/*
   *FunctionName: ServerAnnounce
	 *Parameter: id, load, hostname and port
	 *Return: Null
	 *Description: Constructed Function
	 */
	public ServerAnnounce(String id, int load , String hostname, int port){
		this.id = id;
		this.load = load;
		this.hostname = hostname;
		this.port = port;
	}

	/*
   *FunctionName: getId
	 *Parameter: Null
	 *Return: id
	 *Description: get the id
	 */
	public String getId(){
		return this.id;
	}

	/*
   *FunctionName: getHostname
	 *Parameter: Null
	 *Return: hostname
	 *Description: get the hostname
	 */
	public String getHostname(){
		return this.hostname;
	}

	/*
   *FunctionName: getPort
	 *Parameter: Null
	 *Return: port
	 *Description: get the port
	 */
	public int getPort(){
		return this.port;
	}

	/*
   *FunctionName: getLoad
	 *Parameter: Null
	 *Return: load
	 *Description: get the load
	 */
	public int getLoad(){
		return this.load;
	}
}
