package activitystreamer.util;

import org.json.simple.JSONObject;

/*
 *ClassName: ServerMessage
 *Version: 3.0
 *Authors: Zhao, Song, Fan and Zhang
 */
public class ServerMessage{
	private String command;
	private String username;
	private String secret;
	private String info;
	private JSONObject activity = null;

	/*
   *FunctionName: ServerMessage
	 *Parameter: command and information
	 *Return: Null
	 *Description: Constructed Function
	 */
	public ServerMessage(String command, String info){
		this.command = command;
		//if command is ACTIVITY_BROADCAST, the information is activity
		if(command.equals("AUTHENTICATE")){
			this.secret = info;
		}
		else{
			this.info =info;
		}
	}

	/*
   *FunctionName: ServerMessage
	 *Parameter: command and activity
	 *Return: Null
	 *Description: Constructed Function
	 */
	@SuppressWarnings("unchecked")
	public ServerMessage(String command, JSONObject activity){
		this.command = command;
		this.activity = activity;
	}

	/*
   *FunctionName: ServerMessage
	 *Parameter: command, username and secret
	 *Return: Null
	 *Description: Constructed Function
	 */
	public ServerMessage(String command, String username, String secret){
		this.command = command;
		this.username = username;
		this.secret = secret;
	}

	/*
   *FunctionName: getCommand
	 *Parameter: Null
	 *Return: command
	 *Description: get the command
	 */
	public String getCommand(){
		return this.command;
	}

	/*
   *FunctionName: getCommand
	 *Parameter: Null
	 *Return: username
	 *Description: get the username
	 */
	public String getUsername(){
		return this.username;
	}

	/*
   *FunctionName: getCommand
	 *Parameter: Null
	 *Return: secret
	 *Description: get the secret
	 */
	public String getSecret(){
		return this.secret;
	}

	/*
   *FunctionName: getCommand
	 *Parameter: Null
	 *Return: information
	 *Description: get the information
	 */
	public String getInfo(){
		return this.info;
	}

	/*
   *FunctionName: getCommand
	 *Parameter: Null
	 *Return: activity
	 *Description: get the activity
	 */
	 public JSONObject getActi(){
 		return this.activity;
 	}
}
