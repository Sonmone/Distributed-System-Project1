package activitystreamer.util;

import activitystreamer.server.Connection;

/*
 *ClassName: UserDetail
 *Version: 3.0
 *Authors: Zhao, Song, Fan and Zhang
 */
public class UserDetail{
	//the connection from client
	private Connection con;
	//the number that the register request has been allowed
	private int allowCount = 0;

	/*
   *FunctionName: UserDetail
	 *Parameter: connection
	 *Return: Null
	 *Description: Constructed Function
	 */
	public UserDetail(Connection con){
		this.con = con;
	}

	/*
   *FunctionName: getAllowCount
	 *Parameter: Null
	 *Return: allow count
	 *Description: get the number that the register request has been allowed
	 */
	public int getAllowCount(){
		return allowCount;
	}

	/*
   *FunctionName: setAllowCount
	 *Parameter: allow count
	 *Return: Null
	 *Description: set the number that the register request has been allowed
	 */
	public void setAllowCount(int allowCount){
		this.allowCount = allowCount;
	}

	/*
   *FunctionName: getConnection
	 *Parameter: Null
	 *Return: Connection
	 *Description: get the connection
	 */
	public Connection getConnection(){
		return con;
	}
}
